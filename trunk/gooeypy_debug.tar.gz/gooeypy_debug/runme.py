#!/usr/bin/python2.4

import os
from debug import main
main()
