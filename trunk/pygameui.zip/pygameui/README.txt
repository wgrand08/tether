Pygame.UI

ABOUT

A simple widget system for Pygame in pure Python with no documentation.
This library can be used as plug-in for your existing project.

See demo/demo.py for basic usage. Expect documentation later, if there will be
anyone interesting in this :-)

Anyone interested in this library can contact me. I am willing to setup a
SourceForge project.

License: LGPL
Requirements: Pygame 1.3, Python 2.1
Author: Ludek Smid, qark@ospace.net
